-----
Database title: A global database for metaCommunity Ecology: Species, Traits, Environment and Space - version 1 (CESTES v1.0)
Author: Alienor Jeliazkov 
Contact: cestes@idiv.de
Date: 31/07/2019
Reference citations: 
- Jeliazkov A., (...) & J. Chase (2019) A global database for metacommunity ecology integrating species, traits, environment and space. Scientific Data.
- Jeliazkov & CESTES coll. (2019) A global database for metaCommunity Ecology: Species, Traits, Environment and Space - version 1.0 (CESTES v1.0). URL: https://idata.idiv.de/ddm/data/showdata/286
Project website: https://icestes.github.io/
License: CC BY 4.0
----- 


The present repository includes the following elements:
- "xCESTES" folder 		= includes the 80 datasets from the CESTES database (all Excel files)
- "CESTES_metadata.xlsx" 	= metadata information related to the CESTES database
- "rCESTES" folder includes: 
	-- "CESTES.RData" file 	= the CESTES core processed database (comm, traits, envir, coord matrices) as an R list object 
	-- "CESTES_DataPrep.R" 	= R script for preparing the data for analysis
	-- "CESTES_Plots.R"	= R script for exploring the database and generating the plots from Jeliazkov et al. 2019
	-- "ListDat.csv"	= list of the 139 datasets that were initially requested to the authors
	-- "Metadat.csv"	= extended table of metadata information used for data exploration in the data paper
- "HOW_TO_SHARE_MY_DATA_FOR_CESTES.pdf"	= tutorial explaining how to share your data and join the CESTES consortium
- "LICENSE.txt"  		= the license under which one can use all the content present in this repository (namely, CC BY 4.0). 

Attached to this repository, one can also find: 
- "ceste" folder, which includes: 
	-- the ancillary 10 datasets from the ceste database (all Excel files)
	-- "ceste_metadata.xlsx" 	= the metadata information related to the ceste database.

For more information, see: 
Jeliazkov A., (...) & J. Chase (2019) A global database for metacommunity ecology, integrating species, traits, environment and space. Scientific Data.